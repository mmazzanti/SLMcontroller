import os
import glob
import numpy as np
import matplotlib.pyplot as plt
from numpy import unravel_index
from matplotlib import cm
from matplotlib.ticker import LinearLocator

file_path = os.path.realpath(__file__)

list_of_files = glob.glob('Img\*') # * means all if need specific format then *.csv
latest_file = max(list_of_files, key=os.path.getctime)
print(latest_file)


data = np.load(file_path[:-len(os.path.basename(file_path).split('/')[-1])] + latest_file)

integrated_intensity = data.sum(axis=2)
max_int =  unravel_index(integrated_intensity.argmax(), integrated_intensity.shape)
print("Max : ", max_int)
pltrange = 450

integrated_intensity = integrated_intensity[max_int[0]-pltrange:max_int[0]+pltrange,max_int[1]-pltrange:max_int[1]+pltrange]




integrated_intensity = integrated_intensity/np.amax(integrated_intensity)

xlist = np.linspace(0,integrated_intensity.shape[0], integrated_intensity.shape[0])
ylist = np.linspace(0, integrated_intensity.shape[1], integrated_intensity.shape[1])

print(len(xlist))
print(integrated_intensity.shape)

fig, ax = plt.subplots(subplot_kw={"projection": "3d"})
X, Y = np.meshgrid(xlist, ylist)
# Plot the surface.
surf = ax.plot_surface(X, Y, integrated_intensity, cmap=cm.coolwarm,
                       linewidth=0, antialiased=False)

# Customize the z axis.
ax.set_zlim(0, 1.0)
ax.zaxis.set_major_locator(LinearLocator(10))
# A StrMethodFormatter is used automatically
ax.zaxis.set_major_formatter('{x:.02f}')

# Add a color bar which maps values to colors.
fig.colorbar(surf, shrink=0.5, aspect=5)

plt.show()